library(Rcpp)

compileAttributes(verbose=TRUE)
library("myPackage")



rcpp_hello_world()

multi(5,63)
Add(56,3)
