#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
double multi(double x, double y) {
  
  
  return x*y ;
}