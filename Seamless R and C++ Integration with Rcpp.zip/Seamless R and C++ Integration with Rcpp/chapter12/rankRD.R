src <- '
 using namespace Eigen;
 const Map<MatrixXd> A(as<Map<MatrixXd> >(As));
 FullPivLU<MatrixXd> lu_decomp(A);
 return List::create(Named("rank") = lu_decomp.rank(), Named("nullSpace") = lu_decomp.kernel(),
 Named("colSpace") = lu_decomp.image(A));'

rrEx <- cxxfunction(signature(As = "mat"), body=src, plugin="RcppEigen")
A <- matrix(c(1,2,5, 2,1,4, 3,0,3),3,3,byrow=TRUE)
rrEx(A)
