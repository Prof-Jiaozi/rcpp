src <- '
 using namespace Eigen;
 const Map<MatrixXd> X(as<Map<MatrixXd> >(Xs));
 const Map<VectorXd> y(as<Map<VectorXd> >(ys));
 VectorXd x = X.jacobiSvd(ComputeThinU|ComputeThinV).solve(y);
 return wrap(x);'

lsEx <- cxxfunction(signature(Xs = "matrix", ys = "vector"), body=src, plugin="RcppEigen")
data(cars)
X <- cbind(1, log(cars[,"speed"]))
y <- log(cars[,"dist"])
lsEx(X, y)
