library(inline)
src <- '
 using namespace Eigen;
 const Map<MatrixXd> A(as<Map<MatrixXd> >(As));
 SelfAdjointEigenSolver<MatrixXd> es(A);
 if (es.info() != Success) stop("Problem with Matrix");
 return List::create(Named("values") = es.eigenvalues(), Named("vectors") = es.eigenvectors());'

eigEx <- cxxfunction(signature(As = "mat"), body=src, plugin="RcppEigen")
A <- matrix(c(1,2, 2,3), 2,2, byrow=TRUE)
eigEx(A)
eigEx(matrix(c(1,NA,NA,1),2,2))
