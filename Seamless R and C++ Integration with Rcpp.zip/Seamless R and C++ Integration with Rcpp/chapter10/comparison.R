library(RcppArmadillo)
y <- log(trees$Volume)
X <- cbind(1, log(trees$Girth))
frm <- formula(log(Volume) ~ log(Girth))

benchmark(fLm(X, y),
           fastLmPure(X, y),
           fastLmPure2(X, y),
           fastLm(frm, data=trees),
           columns = c("test", "replications","elapsed", "relative"),
           order="relative",
           replications=1000)
