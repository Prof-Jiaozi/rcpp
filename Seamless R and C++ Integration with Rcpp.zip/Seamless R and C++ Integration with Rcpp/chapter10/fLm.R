src <- '
 Rcpp::NumericMatrix Xr(Xs);
Rcpp::NumericVector yr(ys);
 int n = Xr.nrow(), k = Xr.ncol();
arma::mat X(Xr.begin(), n, k, false);
 arma::colvec y(yr.begin(), yr.size(), false);
int df = n - k;

// fit model y ˜ X, extract residuals
 arma::colvec coef = arma::solve(X, y);
arma::colvec res = y - X*coef;

double s2 = std::inner_product(res.begin(), res.end(),
                                res.begin(), 0.0)/df;
// std.errors of coefficients
 arma::colvec sderr = arma::sqrt(s2 *
                                     arma::diagvec(arma::pinv(arma::trans(X)*X)));

return Rcpp::List::create(Rcpp::Named("coefficients")=coef,
                           Rcpp::Named("stderr") =sderr,
                          Rcpp::Named("df") =df);
 '
fLm <- cxxfunction(signature(Xs="numeric", ys="numeric"), src, plugin="RcppArmadillo")


