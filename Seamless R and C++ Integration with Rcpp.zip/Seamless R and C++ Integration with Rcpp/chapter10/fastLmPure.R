library(RcppArmadillo)
fastLmPure <- function(X, y) {
  
  stopifnot(is.matrix(X))
   stopifnot(nrow(y)==nrow(X))
   .Call("_RcppArmadillo_fastLm_impl", X, y, PACKAGE = "RcppArmadillo")
}
