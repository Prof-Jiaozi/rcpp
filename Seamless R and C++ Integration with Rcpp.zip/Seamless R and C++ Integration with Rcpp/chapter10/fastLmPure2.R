library(RcppArmadillo)
fastLmPure2 <- function(X, y) {
  
   .Call("_RcppArmadillo_fastLm_impl", X, y, PACKAGE = "RcppArmadillo")
}
