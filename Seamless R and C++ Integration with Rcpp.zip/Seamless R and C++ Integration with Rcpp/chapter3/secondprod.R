src <- '
 Rcpp::IntegerVector vec(vx);
 int prod = std::accumulate(vec.begin(),vec.end(), 1, std::multiplies<int>());
 return Rcpp::wrap(prod);
 '

fun <- cxxfunction(signature(vx="integer"), src, plugin="Rcpp")

fun(1:10)



