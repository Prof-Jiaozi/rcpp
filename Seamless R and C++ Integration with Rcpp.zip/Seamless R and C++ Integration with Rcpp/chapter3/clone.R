src <- '
 Rcpp::NumericVector invec(vx);
Rcpp::NumericVector outvec = Rcpp::clone(vx);
for (int i=0; i<invec.size(); i++) {
outvec[i] = log(invec[i]);

}
return outvec;
'
fun <- cxxfunction(signature(vx="numeric"),src, plugin="Rcpp")

x <- seq(1.0, 3.0, by=1)
cbind(x, fun(x))
