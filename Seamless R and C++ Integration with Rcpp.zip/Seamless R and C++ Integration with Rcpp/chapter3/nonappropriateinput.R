src <- '
 Rcpp::IntegerVector vec(vx);
int prod = std::accumulate(vec.begin(),vec.end(), 1, std::multiplies<int>());
return Rcpp::wrap(prod);
'

fun <- cxxfunction(signature(vx="integer"), src, plugin="Rcpp")

fun(seq(1.0, 1.9, by=0.1))

fun(LETTERS[1:10])


