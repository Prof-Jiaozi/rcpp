src <- '
 Rcpp::NumericVector invec(vx);
 Rcpp::NumericVector outvec = log(invec);
 return outvec;
 '

fun <- cxxfunction(signature(vx="numeric"), src, plugin="Rcpp")
x <- seq(1.0, 3.0, by=1)

cbind(x, fun(x))


