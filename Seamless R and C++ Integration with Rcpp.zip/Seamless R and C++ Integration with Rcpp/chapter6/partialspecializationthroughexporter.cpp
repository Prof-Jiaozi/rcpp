namespace Rcpp {
namespace traits {

template <typename T> class Exporter{
   public:
    Exporter( SEXP x ) : t(x){}
     
     inline T get(){ return t; }
      private:
       T t;
        } ;
}
 }