code <- '
// we get a list from R
 List input(inputS) ;
// pull std::vector<double> from R list
// achieved through an implicit call to Rcpp::as
 std::vector<double> x = input["x"] ;
 // return an R list
// achieved through implicit call to Rcpp::wrap
 return List::create(_["front"] = x.front(),_["back"] = x.back());
 '

fx <- cxxfunction(signature(inputS = "list"),body=code, plugin = "Rcpp")

input <- list( x = seq(1, 10, by = 0.5) )
fx( input )
