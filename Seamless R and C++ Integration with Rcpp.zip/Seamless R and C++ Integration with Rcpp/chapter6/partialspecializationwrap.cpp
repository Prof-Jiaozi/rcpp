#include <RcppCommon.h>
 // third party library declarings template class Bling<T>
#include <foobar.h>

// declaring the partial specialization
 namespace Rcpp {
namespace traits {
 template <typename T> SEXP wrap( const Bling<T>& );
}
 }
 // this must appear after the specialization, else
// the specialization will not be seen by Rcpp types
 #include <Rcpp.h>