#include <RcppCommon.h>
class Foo{
public:
   Foo() ;
  // this constructor enables implicit Rcpp::as
  Foo(SEXP) ; }

#include <Rcpp.h>