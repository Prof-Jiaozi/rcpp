#include <RcppCommon.h>
 // third party library that declares class Bar
#include <foobar.h>

// declaring the specialization
 namespace Rcpp {
template <> SEXP wrap( const Bar& );
 }
 // this must appear after the specialization, else
// the specialization will not be seen by Rcpp types
 #include <Rcpp.h>