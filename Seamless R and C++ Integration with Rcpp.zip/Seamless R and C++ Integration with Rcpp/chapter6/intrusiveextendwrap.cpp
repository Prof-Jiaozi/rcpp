#include <RcppCommon.h>

class Foo {
public:
  Foo();
  
// this operator enables implicit Rcpp::wrap
  operator SEXP();
}

#include <Rcpp.h>