foo <- function(x, y){
   ifelse( x < y, x*x, -(y*y) )
}
foo(3,4)
