#include <Rcpp.h>
using namespace Rcpp;



// [[Rcpp::export]]
extern "C" SEXP fun( SEXP x ) {
  try {
    int dx = Rcpp::as<int>(x);
    if (dx > 10)
      throw std::range_error("too big");
    return Rcpp::wrap(dx * dx);
  } catch( std::exception& __ex__) {
    forward_exception_to_r(__ex__);
  } catch(...) {
      ::Rf_error( "c++ exception (unknown reason)" );
      }
  return R_NilValue; // not reached
}