dyn.load("catchexception.so")
.Call("fun", 4)
.Call("fun", -4)
.Call("fun", 11)

.Call("fun", "ABC")
