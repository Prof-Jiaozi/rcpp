src <- 'int dx = Rcpp::as<int>(x);
  if( dx > 10 )
     throw std::range_error("too big");
  return Rcpp::wrap( dx * dx);
'
fun <- cxxfunction(signature(x="interger"), body=src, plugin="Rcpp")

fun(3)
fun(13)


cppFunction('int fun2(int dx) {
              if ( dx > 10 )
              throw std::range_error("too big");
              return dx * dx; }')
fun2(3)

fun2(13)
