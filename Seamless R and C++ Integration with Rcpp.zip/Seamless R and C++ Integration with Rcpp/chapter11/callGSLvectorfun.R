library(Rcpp)
library(RcppGSL)
sourceCpp("GSLvectorexample.cpp")

sum_gsl_vector_int(1:10)

sourceCpp("GSLvector2.cpp")
data <- list( x = seq(0,1,length=10), y = 1:10 )
gsl_vector_sum_2(data)
                