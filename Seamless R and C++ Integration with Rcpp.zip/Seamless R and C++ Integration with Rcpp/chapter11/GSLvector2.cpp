#include <Rcpp.h>
#include <RcppGSL.h>
using namespace Rcpp;


// [[Rcpp::depends(RcppGSL)]]
// [[Rcpp::export]]
double gsl_vector_sum_2(const Rcpp::List & data) {
  // grab "x" as a gsl_vector through the RcppGSL::vector<double> class
  const RcppGSL::vector<double> x = data["x"];
  // grab "y" as a gsl_vector through the RcppGSL::vector<int> class
  const RcppGSL::vector<int> y = data["y"];
  double res = 0.0;
  for (size_t i=0; i< x->size; i++) {
    res += x[i] * y[i];
  }
  return res; // return the result, memory freed automatically
}