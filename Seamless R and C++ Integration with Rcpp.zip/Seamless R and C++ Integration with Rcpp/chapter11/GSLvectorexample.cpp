#include <RcppGSL.h>
#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::depends(RcppGSL)]]
// [[Rcpp::export]]
int sum_gsl_vector_int(const RcppGSL::vector<int> & vec){
  int res = std::accumulate(vec.begin(), vec.end(), 0);
  return res;
}