
Rcpp.package.skeleton("myPackage")
system("ls -1R mypackage")


rcpp_hello_world( )
