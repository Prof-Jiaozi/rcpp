suppressMessages(library(rbenchmark))

res <- benchmark(rcppSim(a,u),
                 rSim(a,u),
                 compRsim(a,u),
                 columns=c("test", "replications", "elapsed",
                           "relative", "user.self", "sys.self"),
                 order="relative")
res
