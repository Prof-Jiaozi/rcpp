library(inline)
inc <- '#include <Rcpp.h>

class Uniform {
public:
Uniform(double min_, double max_) :
min(min_), max(max_) {}

Rcpp::NumericVector draw(int n) {
Rcpp::RNGScope scope;
return Rcpp::runif( n, min, max );
}
private:
double min, max;
};




using namespace Rcpp;
/// create an external pointer to a Uniform object
RcppExport SEXP Uniform__new(SEXP min_, SEXP max_) {
// convert inputs to appropriate C++ types
double min = as<double>(min_), max = as<double>(max_);

// create a pointer to an Uniform object and wrap it
// as an external pointer
Rcpp::XPtr<Uniform> ptr( new Uniform( min, max ), true );

// return the external pointer to the R side
return ptr;
}

/// invoke the draw method
RcppExport SEXP Uniform__draw( SEXP xp, SEXP n_ ) {
// grab the object as a XPtr (smart pointer) to Uniform
Rcpp::XPtr<Uniform> ptr(xp);
// convert the parameter to int
int n = as<int>(n_);

// invoke the function
NumericVector res = ptr->draw( n );
// return the result to R
return res;
}
'

 f1 <- cxxfunction( , "", includes = inc, plugin = "Rcpp" )
 getDynLib(f1)
 

 setClass("Uniform", representation( pointer = "externalptr" ) )
 # helper
 Uniform_method <- function(name) {
   paste( "Uniform", name, sep = "__" )
 }
 
 # syntactic sugar to allow object$method( ... )
 setMethod( "$", "Uniform", function(x, name ) {
   function(...) .Call(Uniform_method(name),
                       x@pointer, ... )
 } )
 
 # syntactic sugar to allow new( "Uniform", ... )
 setMethod("initialize",
           "Uniform", function(.Object, ...) {
             .Object@pointer <-
               .Call(Uniform_method("new"), ... )
             .Object
           } )
 
 u <- new( "Uniform", 0, 10 )
 u$draw( 10L )
 
 