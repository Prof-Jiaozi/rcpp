inc<-'
typedef std::vector<double> vec; // convenience typedef
void vec_assign( vec* obj, Rcpp::NumericVector data ) { // helpers
obj->assign( data.begin(), data.end() );
}
void vec_insert( vec* obj, int position, Rcpp::NumericVector data) {
vec::iterator it = obj->begin() + position;
obj->insert( it, data.begin(), data.end() );
}
Rcpp::NumericVector vec_asR( vec* obj ) { return Rcpp::wrap( *obj ); }
void vec_set( vec* obj, int i, double value ) { obj->at( i ) = value; }
RCPP_MODULE(mod_vec) {
using namespace Rcpp;

class_<vec>( "vec")

.constructor()
.constructor<int>()

.method( "size", &vec::size)
.method( "max_size", &vec::max_size)
//.method( "resize", &vec::resize)
.method( "capacity", &vec::capacity)
.method( "empty", &vec::empty)
.method( "reserve", &vec::reserve)
.method( "push_back", &vec::push_back )
.method( "pop_back", &vec::pop_back )
.method( "clear", &vec::clear )

.const_method( "back", &vec::back )
.const_method( "front", &vec::front )
.const_method( "at", &vec::at )

.method( "assign", &vec_assign )
.method( "insert", &vec_insert )
.method( "as.vector", &vec_asR )

.const_method( "[[", &vec::at )
.method( "[[<-", &vec_set );
}'

fx_vec<- cxxfunction(signature(), plugin="Rcpp", include=inc)
mod_vec <- Module( "mod_vec", getDynLib(fx_vec), mustStart = TRUE )

vec <- mod_vec$vec
 v <- new( vec )
 v$reserve( 50L )
 v$assign( 1:10 )
 v$push_back( 10 )
 v$size()
 v$capacity()
 v[[ 0L ]]
 v$as.vector()
 