dyn.load("norm.so")

norm <- function(x, y){
  .Call( "norm_wrapper", x, y )
}

norm(3,4)
