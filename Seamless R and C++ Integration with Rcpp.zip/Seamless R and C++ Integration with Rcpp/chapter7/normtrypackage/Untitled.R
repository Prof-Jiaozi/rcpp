Rcpp.package.skeleton("normpackage")
compileAttributes(verbose=TRUE)
library(normpackage)

normpackage(3,4)
rcpp_hello_world()

