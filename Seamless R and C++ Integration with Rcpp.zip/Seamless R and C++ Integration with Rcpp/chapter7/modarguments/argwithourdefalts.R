inc<-'using namespace Rcpp;
double norm( double x, double y ) {
  return sqrt( x*x + y*y );
}
RCPP_MODULE(mod_formals2) {
  function("norm", &norm,
           List::create( _["x"], _["y"] = 0.0 ),
           "Provides a simple vector norm");
}'
fx <- cxxfunction(signature(), plugin="Rcpp", include=inc)
mod <- Module("mod_formals2", getDynLib(fx))

norm <- mod$norm
 args(norm)
 