inc <- '
std::string hello() {
  return "hello";
}
int bar( int x) {
return x*2;
}
double foo( int x, double y) {
return x * y;
}
void bla( ) {
Rprintf( "hello\\n" );
}
void bla1( int x) {
Rprintf( "hello (x = %d)\\n", x );
}
void bla2( int x, double y) {
Rprintf( "hello (x = %d, y = %5.2f)\\n", x, y );
}

RCPP_MODULE(yada) {
using namespace Rcpp;
function("hello" , &hello);
function("bar" , &bar );
function("foo" , &foo );
function("bla" , &bla );
function("bla1" , &bla1 );
function("bla2" , &bla2 );
}
'

fx <- cxxfunction(signature(), plugin="Rcpp", include=inc)
yd <- Module("yada", getDynLib(fx))
require( Rcpp )

yd$bar(2L)
yd$foo(2L, 10.0)
yd$hello()
yd$bla()
yd$bla1(2L)
yd$bla2(2L, 5.0)
