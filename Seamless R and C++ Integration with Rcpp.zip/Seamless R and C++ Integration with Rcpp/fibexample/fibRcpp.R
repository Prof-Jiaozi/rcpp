library(Rcpp)
sourceCpp("fibonacci.cpp")
fibonacci(20)
