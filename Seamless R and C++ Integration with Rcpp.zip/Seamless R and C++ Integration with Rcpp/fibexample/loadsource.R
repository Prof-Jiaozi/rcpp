dyn.load("fibonacci.so")
.Call("fibWrapper", 10)

.Call("fibWrapper", 20)
