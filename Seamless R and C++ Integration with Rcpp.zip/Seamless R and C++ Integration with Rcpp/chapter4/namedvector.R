someVec <- c(mean=1.23, dim=42.0, cnt=12)
someVec


