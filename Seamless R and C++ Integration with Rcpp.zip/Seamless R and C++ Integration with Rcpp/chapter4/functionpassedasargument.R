src <- ' Function sort(x) ;
 return sort( y, Named("decreasing", true));'

fun <- cxxfunction(signature(x="function", y="ANY"), src, plugin="Rcpp")

fun(sort, sample(1:5, 10, TRUE))
fun(sort, sample(LETTERS[1:5], 10, TRUE))




