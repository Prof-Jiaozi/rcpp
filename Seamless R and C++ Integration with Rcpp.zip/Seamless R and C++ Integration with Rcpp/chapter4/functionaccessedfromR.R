src <- ' RNGScope scp;
 Rcpp::Function rt("rt");
 return rt(5, 3); '

fun <- cxxfunction(signature(), src, plugin="Rcpp")
set.seed(42)

fun()
fun()


