return Rcpp::List::create(Rcpp::Named("bestmem") = t_bestP,
                          Rcpp::Named("bestval") = t_bestC,
                           Rcpp::Named("nfeval") = l_nfeval,
                          Rcpp::Named("iter") = i_iter,
                           Rcpp::Named("bestmemit") =
                            t(d_bestmemit),
                           Rcpp::Named("bestvalit") = d_bestvalit,
                          Rcpp::Named("pop") = t(d_pop),
                           Rcpp::Named("storepop") = d_storepop);


