f2 <- cxxfunction(signature(x="any"), plugin="Rcpp", body='
                   S4 foo(x);
                  foo.slot(".Data") = "foooo";
                   return foo;
                  ')


