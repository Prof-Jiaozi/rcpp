f1 <- cxxfunction(signature(x="any"), plugin="Rcpp", body='
                  RObject y(x) ;
                   List res(3) ;
                  res[0] = y.isS4();
                  res[1] = y.hasSlot("z");
                   res[2] = y.slot("z");
                   return res;
                  ')

f1()


